from flet import *
from views import *
from catalog import*
from reminder import*


def main(page: Page):
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    
    def route_change(route):
        print(page.route)
        print(views_handler(page))
        page.views.clear()
        page.views.append(
            views_handler(page)[page.route]
        )
        page.update()
    
    def go_to_catalog(e):
        #e.page.go("catalog.py")
        print("updated")
    
    page.on_route_change = route_change
    #page.go('/catalog')
    
    _main_content_ = Column(
        
        scroll="hidden",
        expand=True,
        alignment=MainAxisAlignment.START,
        controls=[
            Row(
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                
                controls=[
                    Text("       MEMORISE", size=28,weight="bold"),
                    
                ],
            ),
        ],
    )
    
    page.add(
            
            Container(
                width=1500,
                height=800,
                margin=10,
                bgcolor="bluegrey900",
                alignment=alignment.center,
                content=Row(
                    alignment=MainAxisAlignment.CENTER,
                    vertical_alignment=CrossAxisAlignment.CENTER,
                    controls=[
                        Container(
                            width=300, 
                            height=600, 
                            bgcolor="#0f0f0f",
                            border_radius=40,
                            border=border.all(0.5, "white"),
                            padding=padding.only(top=35, left=20, right=20),
                            clip_behavior=ClipBehavior.HARD_EDGE,
                            content=Column(
                                alignment=MainAxisAlignment.CENTER,
                                expand=True,
                                controls=[
                                    _main_content_,
                                    Container(
                                    alignment=alignment.center,
                                    content=ElevatedButton(
                                        #on_click=go_to_catalog('catalog.py'),
                                        bgcolor='grey24',
                                        content=Text(
                                            "Task Planner",
                                            size=22,
                                            weight="bold",
                                            color="black",
                                        ),
                                        style=ButtonStyle(
                                            shape={
                                                "":RoundedRectangleBorder(radius=8),
                                            },
                                            color={"":"white"},
                                        ),
                                        height=75,
                                        width=200,
                                    ),
                                ),
                                    Container(
                                    alignment=alignment.center,
                                    content=ElevatedButton(
                                        #on_click=lambda _: Page.go('reminder.py'),
                                        bgcolor='grey24',
                                        content=Text(
                                            "Set Reminder",
                                            size=22,
                                            weight="bold",
                                            color="black",
                                        ),
                                        style=ButtonStyle(
                                            shape={
                                                "":RoundedRectangleBorder(radius=8),
                                            },
                                            color={"":"white"},
                                        ),
                                        height=75,
                                        width=200,
                                    ),
                                ),
                                    
                                ],
                            )
                        )
                    ],
                )  
            )
        )
    
    page.update()
    
if __name__=="__main__":
    flet.app(target=main)

