from flet import *
from catalog import*
from reminder import*
#from home1 import*
from app import*

def views_handler(page):
    return{
        '/app':View(
            route='/app',
            controls=[
                app(page)
            ]
        ),
        
        '/catalog':View(
            route='/catalog',
            controls=[
                Catalog(page)
            ]
        ),
        '/reminder':View(
            route='/reminder',
            controls=[
                Reminder(page)
            ]
        ),
    }