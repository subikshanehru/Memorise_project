if __name__=="__main__":
    flet.app(target=main)
